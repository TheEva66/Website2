// /pages/fy103.tsx
import { FC } from 'react';
import GobletOfFire from '../components/Sections/GobletOfFire';

const FY103: FC = () => {
  return <GobletOfFire />;
};

export default FY103;
